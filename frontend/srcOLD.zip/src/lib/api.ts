import { UserBest } from "./bests";

export async function getBests(userId: number): Promise<UserBest[]> {
  const r = await fetch(`/coach/bests/${userId}`);
  if (!r.ok) throw new Error(`GET bests failed: ${r.status}`);
  const data = await r.json();
  return (data?.bests ?? []) as UserBest[];
}

export async function saveBest(userId: number, payload: {
  distance_m: number;
  time_str?: string;
  time_sec?: number;
  event_name?: string;
  date?: string; // YYYY-MM-DD
}) {
  const r = await fetch(`/coach/bests/${userId}`, {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });
  if (!r.ok) throw new Error(`PUT best failed: ${r.status}`);
  return r.json();
}