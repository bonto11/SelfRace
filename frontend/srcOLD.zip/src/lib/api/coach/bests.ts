// src/lib/api/coach/bests.ts
import { API_URL } from "@/lib/config";
import type { Best } from "@/types/coach";

export async function getBests(userId: number): Promise<Best[]> {
  const r = await fetch(`${API_URL}/coach/bests/${userId}`, { cache: "no-store" });
  if (!r.ok) throw new Error(`bests load failed: ${r.status}`);
  const j = await r.json().catch(() => ({}));
  return j?.bests ?? [];
}

// Backend prijíma: { distance_m|distance_km?, time_sec|time_str, event_name?, date? }
// My mu pošleme distance_m a time_sec (ak vieme), inak time_str.
export async function saveBest(userId: number, best: Best): Promise<void> {
  const r = await fetch(`${API_URL}/coach/bests/${userId}`, {
    method: "PUT",
    headers: { "content-type": "application/json" },
    body: JSON.stringify(best),
  });
  if (!r.ok) {
    const j = await r.json().catch(() => ({}));
    throw new Error(j?.detail ?? `save best failed: ${r.status}`);
  }
}

export const BEST_DISTANCES_M = [400, 1000, 5000, 21097, 42195] as const;
export type BestDistanceM = typeof BEST_DISTANCES_M[number];

export function distanceLabel(m: number): string {
  switch (m) {
    case 400: return "400 m";
    case 1000: return "1 km";
    case 5000: return "5 km";
    case 21097: return "21.097 km (polmaratón)";
    case 42195: return "42.195 km (maratón)";
    default: return `${(m/1000).toFixed(3)} km`;
  }
}

export type UserBest = {
  distance_m: number;
  best_time_s?: number | null;
  time_str?: string | null;
  event_name?: string | null;
  date?: string | null; // YYYY-MM-DD
};

