import { useEffect, useMemo, useState } from "react";
import { BEST_DISTANCES_M, UserBest } from "@/lib/coach/bests";
import { getBests } from "@/lib/api";

export function useUserBests(userId: number | null) {
  const [loading, setLoading] = useState(false);
  const [bests, setBests] = useState<UserBest[]>([]);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!userId) return;
    setLoading(true);
    getBests(userId)
      .then((rows) => {
        setBests(rows || []);
      })
      .catch((e) => setError(String(e)))
      .finally(() => setLoading(false));
  }, [userId]);

  // vyplníme chýbajúce vzdialenosti prázdnymi záznamami, aby mal modal stále všetky polia
  const normalized = useMemo(() => {
    const map = new Map<number, UserBest>();
    for (const b of bests) map.set(b.distance_m, b);
    return BEST_DISTANCES_M.map((d) => map.get(d) ?? { distance_m: d });
  }, [bests]);

  return { loading, error, bests: normalized, setBests };
}
