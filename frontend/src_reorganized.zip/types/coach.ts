// AUTO-GENERATED SHIM: re-export from reorganized location
export * from "@/shared/types/coach.ts";
export { default } from "@/shared/types/coach.ts";
