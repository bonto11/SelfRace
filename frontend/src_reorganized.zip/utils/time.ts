// AUTO-GENERATED SHIM: re-export from reorganized location
export * from "@/shared/utils/time.ts";
export { default } from "@/shared/utils/time.ts";
