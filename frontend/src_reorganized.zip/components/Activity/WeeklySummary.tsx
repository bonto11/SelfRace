// AUTO-GENERATED SHIM: re-export from reorganized location
export * from "@/shared/components/ui/WeeklySummary.tsx";
export { default } from "@/shared/components/ui/WeeklySummary.tsx";
