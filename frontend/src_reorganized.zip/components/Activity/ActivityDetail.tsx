// AUTO-GENERATED SHIM: re-export from reorganized location
export * from "@/shared/components/ui/ActivityDetail.tsx";
export { default } from "@/shared/components/ui/ActivityDetail.tsx";
