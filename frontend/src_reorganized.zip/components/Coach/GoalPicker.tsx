// AUTO-GENERATED SHIM: re-export from reorganized location
export * from "@/features/coach/components/GoalPicker.tsx";
export { default } from "@/features/coach/components/GoalPicker.tsx";
