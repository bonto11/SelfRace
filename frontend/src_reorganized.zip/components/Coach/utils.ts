// AUTO-GENERATED SHIM: re-export from reorganized location
export * from "@/features/coach/components/utils.ts";
export { default } from "@/features/coach/components/utils.ts";
