// AUTO-GENERATED SHIM: re-export from reorganized location
export * from "@/features/coach/components/Calendar.tsx";
export { default } from "@/features/coach/components/Calendar.tsx";
