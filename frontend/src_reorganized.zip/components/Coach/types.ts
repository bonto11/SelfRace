// AUTO-GENERATED SHIM: re-export from reorganized location
export * from "@/features/coach/components/types.ts";
export { default } from "@/features/coach/components/types.ts";
