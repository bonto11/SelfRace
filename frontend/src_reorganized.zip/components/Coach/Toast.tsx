// AUTO-GENERATED SHIM: re-export from reorganized location
export * from "@/features/coach/components/Toast.tsx";
export { default } from "@/features/coach/components/Toast.tsx";
