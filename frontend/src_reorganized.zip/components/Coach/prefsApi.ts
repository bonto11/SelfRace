// AUTO-GENERATED SHIM: re-export from reorganized location
export * from "@/features/coach/components/prefsApi.ts";
export { default } from "@/features/coach/components/prefsApi.ts";
