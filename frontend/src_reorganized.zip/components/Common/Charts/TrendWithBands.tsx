// AUTO-GENERATED SHIM: re-export from reorganized location
export * from "@/shared/components/charts/TrendWithBands.tsx";
export { default } from "@/shared/components/charts/TrendWithBands.tsx";
