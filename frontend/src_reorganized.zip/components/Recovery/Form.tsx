// AUTO-GENERATED SHIM: re-export from reorganized location
export * from "@/features/recovery/components/Form.tsx";
export { default } from "@/features/recovery/components/Form.tsx";
