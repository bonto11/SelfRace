// AUTO-GENERATED SHIM: re-export from reorganized location
export * from "@/features/recovery/components/Columns.tsx";
export { default } from "@/features/recovery/components/Columns.tsx";
