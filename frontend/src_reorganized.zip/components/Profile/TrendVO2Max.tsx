// AUTO-GENERATED SHIM: re-export from reorganized location
export * from "@/features/profile/components/TrendVO2Max.tsx";
export { default } from "@/features/profile/components/TrendVO2Max.tsx";
