// AUTO-GENERATED SHIM: re-export from reorganized location
export * from "@/features/profile/components/TableHistory.tsx";
export { default } from "@/features/profile/components/TableHistory.tsx";
