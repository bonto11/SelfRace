// AUTO-GENERATED SHIM: re-export from reorganized location
export * from "@/shared/components/ui/Sidebar.tsx";
export { default } from "@/shared/components/ui/Sidebar.tsx";
