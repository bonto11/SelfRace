// AUTO-GENERATED SHIM: re-export from reorganized location
export * from "@/shared/components/ui/Topbar.tsx";
export { default } from "@/shared/components/ui/Topbar.tsx";
