// AUTO-GENERATED SHIM: re-export from reorganized location
export * from "@/shared/api/user/useUser.ts";
export { default } from "@/shared/api/user/useUser.ts";
