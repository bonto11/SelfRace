// AUTO-GENERATED SHIM: re-export from reorganized location
export * from "@/shared/api/common/supabaseClient.ts";
export { default } from "@/shared/api/common/supabaseClient.ts";
