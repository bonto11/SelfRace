// AUTO-GENERATED SHIM: re-export from reorganized location
export * from "@/shared/api/common/bands.ts";
export { default } from "@/shared/api/common/bands.ts";
