// AUTO-GENERATED SHIM: re-export from reorganized location
export * from "@/shared/api/coach/coachApi.ts";
export { default } from "@/shared/api/coach/coachApi.ts";
